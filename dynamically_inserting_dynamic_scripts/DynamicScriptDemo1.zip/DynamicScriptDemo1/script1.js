alert('Script 1 Loaded');
document.getElementById('message').innerHTML = 'Script 1 Loaded';