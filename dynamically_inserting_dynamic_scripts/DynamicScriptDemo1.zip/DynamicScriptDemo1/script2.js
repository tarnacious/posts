alert('Script 2 Loaded');
document.getElementById('message').innerHTML = 'Script 2 Loaded';